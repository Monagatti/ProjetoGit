<?php
require_once __DIR__ . '/includes/auth.php';
requireLogin();
$activePage = 'study_cycles.php';
$uid = $_SESSION['user_id'];

$perfil = getPerfil($pdo, $uid);
if (!$perfil) { header('Location: onboarding.php'); exit; }

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'clear_schedule') {
    $pdo->prepare("DELETE FROM agenda_ciclo WHERE usuario_id = ?")->execute([$uid]);
    header('Location: study_cycles.php');
    exit;
}

// Ciclo ativo
$stmt = $pdo->prepare("SELECT id FROM ciclos WHERE usuario_id = ? AND status = 'ativo' ORDER BY id DESC LIMIT 1");
$stmt->execute([$uid]);
$ciclo = $stmt->fetch(PDO::FETCH_ASSOC);
$cicloId = $ciclo['id'] ?? null;

// Itens do ciclo (matérias com minutos calculados pelo peso)
$itens = [];
if ($cicloId) {
    $stmt = $pdo->prepare("SELECT ic.*, m.nome as materia_nome, m.cor as materia_cor
                            FROM itens_ciclo ic JOIN materias m ON m.id = ic.materia_id
                            WHERE ic.ciclo_id = ? ORDER BY ic.ordem_execucao");
    $stmt->execute([$cicloId]);
    $itens = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Agenda já montada (dia/horario -> item)
$stmt = $pdo->prepare("SELECT a.*, ic.materia_id, ic.minutos_alocados, m.nome as materia_nome, m.cor as materia_cor
                        FROM agenda_ciclo a
                        JOIN itens_ciclo ic ON ic.id = a.item_ciclo_id
                        JOIN materias m ON m.id = ic.materia_id
                        WHERE a.usuario_id = ?");
$stmt->execute([$uid]);
$agendaRows = $stmt->fetchAll(PDO::FETCH_ASSOC);
$agendaMap = [];
foreach ($agendaRows as $r) $agendaMap[$r['dia_semana'] . '_' . $r['horario']] = $r;

$days = ['Seg','Ter','Qua','Qui','Sex','Sáb','Dom'];
$times = ['08:00','10:00','14:00','16:00','19:00','21:00'];

$totalMinutos = array_sum(array_column($itens, 'minutos_alocados'));
$totalHoras = floor($totalMinutos / 60);
$totalMinRem = $totalMinutos % 60;
$sessoesAgendadas = count($agendaRows);
$materiasAtivas = count($itens);
$cobertura = $materiasAtivas > 0 ? min(100, round(($sessoesAgendadas / $materiasAtivas) * 100)) : 0;
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>StudyFlow - Ciclo de Estudos</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="app">
    <?php include __DIR__ . '/includes/sidebar.php'; ?>

    <main class="main">
        <div class="page-header">
            <div>
                <h1>Ciclo de Estudos</h1>
                <p><?= htmlspecialchars($perfil['vestibular_sigla']) ?> · <?= htmlspecialchars($perfil['curso_nome']) ?> · calculado com base no peso de cada matéria e em <?= $perfil['horas_disponiveis_semana'] ?>h semanais</p>
            </div>
            <div class="header-actions">
                <a href="onboarding.php?refazer=1" class="btn">🔁 Refazer Ciclo</a>
                <form method="POST" onsubmit="return confirm('Limpar toda a agenda?');">
                    <input type="hidden" name="action" value="clear_schedule">
                    <button type="submit" class="btn">🗑 Limpar Agenda</button>
                </form>
            </div>
        </div>

        <div class="stats-grid">
            <div class="stat-card"><div class="stat-value"><?= $totalHoras ?>h <?= $totalMinRem ?>m</div><div class="stat-sub">Tempo Total do Ciclo / Semana</div></div>
            <div class="stat-card"><div class="stat-value" style="color:var(--green);"><?= $sessoesAgendadas ?></div><div class="stat-sub">Sessões Agendadas</div></div>
            <div class="stat-card"><div class="stat-value" style="color:var(--orange);"><?= $materiasAtivas ?></div><div class="stat-sub">Matérias no Ciclo</div></div>
            <div class="stat-card"><div class="stat-value" style="color:var(--blue);"><?= $cobertura ?>%</div><div class="stat-sub">Cobertura da Agenda</div></div>
        </div>

        <div class="cycles-layout">
            <div class="panel">
                <h2 style="font-size:16px; margin-bottom:4px;">Matérias do seu Ciclo</h2>
                <p style="font-size:12px; color:var(--text-dim); margin-bottom:16px;">Tempo calculado automaticamente pelo peso de cada matéria em <?= htmlspecialchars($perfil['curso_nome']) ?>. Arraste para a agenda ao lado.</p>
                <div id="subjects-list">
                    <?php foreach ($itens as $it): ?>
                        <div class="subject-chip" style="background:<?= $it['materia_cor'] ?>;" draggable="true" data-item-id="<?= $it['id'] ?>" data-name="<?= htmlspecialchars($it['materia_nome']) ?>" data-color="<?= $it['materia_cor'] ?>">
                            <div>
                                ⋮⋮ <?= htmlspecialchars($it['materia_nome']) ?>
                                <small>⏱ <?= $it['minutos_alocados'] ?> min/semana</small>
                            </div>
                        </div>
                    <?php endforeach; ?>
                    <?php if (empty($itens)): ?>
                        <p style="color:var(--text-dim); font-size:13px;">Nenhuma matéria com peso cadastrada para este curso ainda.</p>
                    <?php endif; ?>
                </div>
            </div>

            <div class="panel" style="overflow-x:auto;">
                <h2 style="font-size:16px; margin-bottom:16px;">Agenda Semanal</h2>
                <table class="schedule-table">
                    <thead>
                        <tr>
                            <th>Hora</th>
                            <?php foreach ($days as $d): ?><th><?= $d ?></th><?php endforeach; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($times as $t): ?>
                        <tr>
                            <td class="time-cell"><?= $t ?></td>
                            <?php foreach ($days as $d):
                                $key = $d . '_' . $t;
                                $filled = $agendaMap[$key] ?? null;
                            ?>
                            <td>
                                <div class="drop-slot" data-day="<?= $d ?>" data-time="<?= $t ?>">
                                    <?php if ($filled): ?>
                                        <div class="placed" style="background:<?= $filled['materia_cor'] ?>;" data-agenda-id="<?= $filled['id'] ?>">
                                            <span><?= htmlspecialchars($filled['materia_nome']) ?></span>
                                            <span class="remove-slot" style="cursor:pointer;">✕</span>
                                        </div>
                                    <?php else: ?>
                                        Arraste a matéria aqui
                                    <?php endif; ?>
                                </div>
                            </td>
                            <?php endforeach; ?>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>
</div>

<div class="help-fab">?</div>

<script>
let draggedItem = null;

document.querySelectorAll('.subject-chip').forEach(chip => {
    chip.addEventListener('dragstart', () => {
        draggedItem = { itemId: chip.dataset.itemId, name: chip.dataset.name, color: chip.dataset.color };
    });
});

document.querySelectorAll('.drop-slot').forEach(slot => {
    slot.addEventListener('dragover', e => { e.preventDefault(); slot.classList.add('dragover'); });
    slot.addEventListener('dragleave', () => slot.classList.remove('dragover'));
    slot.addEventListener('drop', e => {
        e.preventDefault();
        slot.classList.remove('dragover');
        if (!draggedItem) return;

        fetch('api/schedule.php', {
            method: 'POST',
            headers: {'Content-Type':'application/json'},
            body: JSON.stringify({
                action: 'place',
                item_ciclo_id: draggedItem.itemId,
                day: slot.dataset.day,
                time: slot.dataset.time
            })
        }).then(r => r.json()).then(() => location.reload());
    });
});

document.querySelectorAll('.remove-slot').forEach(btn => {
    btn.addEventListener('click', e => {
        e.stopPropagation();
        const id = btn.closest('.placed').dataset.agendaId;
        fetch('api/schedule.php', {
            method: 'POST',
            headers: {'Content-Type':'application/json'},
            body: JSON.stringify({ action: 'remove', id })
        }).then(r => r.json()).then(() => location.reload());
    });
});
</script>
</body>
</html>
